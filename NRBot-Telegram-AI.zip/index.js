const { Telegraf } = require('telegraf');
const axios = require('axios');

const BOT_TOKEN = '7251329699:AAF-XMHwVXIt9pdBoS-6gU7fyluVlx1mOmw';
const OPENAI_API_KEY = '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';

const bot = new Telegraf(BOT_TOKEN);

bot.start((ctx) => {
  ctx.reply(`Halo! Saya NRBot 🤖 powered by ChatGPT.
Tanya apa saja tentang NR Real!`);
});

bot.on('text', async (ctx) => {
  const userInput = ctx.message.text;

  try {
    const result = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: userInput }],
      },
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
        },
      }
    );

    const aiText = result.data.choices[0].message.content;
    ctx.reply(aiText);
  } catch (err) {
    console.error('OpenAI Error:', err.response?.data || err.message);
    ctx.reply('❌ Maaf, ada masalah teknis dengan AI. Coba lagi nanti ya.');
  }
});

bot.launch();
console.log('🤖 NRBot Telegram sudah online...');